sqlite3 data/bot.db < schema.sql

CREATE TABLE IF NOT EXISTS owners (
    user_id TEXT PRIMARY KEY,
    kind TEXT NOT NULL DEFAULT 'owner',
    guild_id TEXT,
    added_by TEXT,
    added_at TEXT,
);

CREATE TABLE IF NOT EXISTS blacklist (
    user_id TEXT PRIMARY KEY,
    reason TEXT,
    added_by TEXT,
    added_at TEXT,
);

CREATE TABLE IF NOT EXISTS guild_config (
   guild_id TEXT PRIMARY KEY,
   data TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS ban (
    user_id TEXT,
    reason TEXT,
    added_by TEXT,
    added_at TEXT,
);

CREATE TABLE IF NOT EXISTS levels_config (
    guild_id TEXT PRIMARY KEY,
    data TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS custom_commands (
    guild_id TEXT,
    name TEXT,
    response TEXT,
    enable INTEGER DEFAULT 1,
    PRIMARY KEY (guild_id, name)
);

CREATE TABLE IF NOT EXISTS auto_react (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    guid_id TEXT,
    channel_id TEXT,
    emoji TEXT,
    enabled INTEGER DEFAULT 1
);

CREATE TABLE IF NOT EXISTS reaction_roles (
    guild_id TEXT,
    message_id TEXT,
    emoji TEXT,
    role_id TEXT,
    PRIMARY KEY (guild_id, message_id, emoji)
);

CREATE TABLE IF NOT EXISTS banned_words (
    word TEXT PRIMARY KEY,
    added_by TEXT,
    added_at TEXT,   
);

CREATE TABLE IF NOT EXISTS infractions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT,
    raison TEXT,
    added_by TEXT,
    created_at TEXT
);

CREATE TABLE IF NOT EXISTS notes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT,
    note TEXT,
    added_by TEXT,
    created_at TEXT
);

CREATE TABLE IF NOT EXISTS sanctions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT,
    raison TEXT,
    added_by TEXT,
    created_at TEXT
);

CREATE TABLE IF NOT EXISTS temproles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id TEXT,
    user_id TEXT,
    role_id TEXT,
    until REAL,
    created_at TEXT
);

CREATE TABLE IF NOT EXISTS backups (
    name TEXT PRIMARY KEY,
    guild_name TEXT,
    data TEXT NOT NULL,
    created_at TEXT
);

CREATE TABLE IF NOT EXISTS birthdays ( 
    user_id TEXT PRIMARY KEY,
    date TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS reports (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    reporter_id TEXT,
    target TEXT,
    raison TEXT,
    created_at TEXT
);

CREATE TABLE IF NOT EXISTS locked_names ( 
    user_id TEXT PRIMARY KEY,
    data TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS audit_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT,
    description TEXT,
    created_at TEXT
);

CREATE TABLE IF NOT EXISTS kick (
    user_id INTEGER PRIMARY KEY AUTOINCREMENT,
    target TEXT,
    author TEXT,
    raison TEXT,
    added_by TEXT,
    created_at TEXT
);

CREATE TABLE IF NOT EXISTS xp (
    guild_id TEXT,
    user_id TEXT,
    xp INTEGER DEFAULT 0,
    level INTEGER DEFAULT 1,
    PRIMARY KEY (guild_id, user_id)
);

CREATE TABLE IF NOT EXISTS ticket_message (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id TEXT,
    user_id TEXT,
    author TEXT,
    content TEXT,
    created_at TEXT
);

CREATE TABLE IF NOT EXISTS moderation ( 
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id TEXT,
    kind TEXT,
    payload TEXT,
    created_at TEXT
);
